# Atividades de Laboratório - Sistemas Embarcados I

1. O programa disponibilizado na pasta **stm32f411-blackpill** pisca o LED conectado ao pino PC13 no kit STM32F411 Blackpill. Faça um *fork* deste repositório e altere o programa para que, ao se pressionar o botão conectado a PA0 o LED fique aceso e, ao soltar este botão, o LED se apague.

2. Faça um novo *fork* deste repositório e altere o programa para que, ao se pressionar o botão conectado a PA0 o estado do LED seja trocado, ou seja, caso o LED esteja apagado ao se pressionar o LED uma vez o mesmo deve acender ao pressionar o botão o LED deverá apagar.
